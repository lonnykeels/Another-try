import { useState } from 'react';

const Card = ({ children, className }) => (
  <div className={`bg-white rounded shadow p-4 ${className || ""}`}>{children}</div>
);

const CardContent = ({ children }) => <div>{children}</div>;

const Button = ({ children, ...props }) => (
  <button className="bg-blue-600 text-white rounded px-4 py-2 w-full" {...props}>
    {children}
  </button>
);

const questions = [
  {
    id: 1,
    text: "Hi Michael, I’m your Personalized ReJobber. I know you’ve had a long run as a mortgage underwriter, and I’m here to help you discover fresh career options that match your skills — and maybe even surprise you. How are you feeling about switching careers right now?",
    options: ["Overwhelmed", "Open but unsure", "Excited to explore"]
  },
  {
    id: 2,
    text: "What parts of your mortgage underwriting role did you enjoy most?",
    input: true
  },
  {
    id: 3,
    text: "What parts burned you out or didn’t feel like a fit?",
    input: true
  },
  {
    id: 4,
    text: "Do you want to stay in finance, or try something totally different?",
    options: ["Stay in finance", "Try something new", "Not sure"]
  },
  {
    id: 5,
    text: "How important are income, flexibility, and purpose to you — rank them?",
    input: true
  },
  {
    id: 6,
    text: "Are there any personal interests or hobbies you wish you could work into your job?",
    input: true
  },
  {
    id: 7,
    text: "Tell me about a time you solved a tricky problem, trained someone, or improved a process.",
    input: true
  },
  {
    id: 8,
    text: "If you could shadow someone in any career for a week — who would it be?",
    input: true
  }
];

export default function PersonalizedReJobber() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState({});

  const handleAnswer = (answer) => {
    const currentQuestion = questions[step];
    setAnswers(prev => ({ ...prev, [currentQuestion.id]: answer }));
    setStep(prev => prev + 1);
  };

  const current = questions[step];

  if (step >= questions.length) {
    return (
      <Card className="max-w-xl mx-auto mt-10 text-center">
        <CardContent>
          <h2 className="text-xl font-bold mb-4">Thanks, Michael!</h2>
          <p className="mb-4">Based on your answers, here are a few potential new paths you might explore:</p>
          <ul className="text-left list-disc list-inside">
            <li>Financial educator or course creator</li>
            <li>Business analyst in a non-finance field</li>
            <li>Real estate tech consultant</li>
            <li>Operations coordinator for a startup</li>
            <li>Something totally new — like UX research or career coaching</li>
          </ul>
          <p className="mt-4">Want to explore next steps or training for any of these? Let’s chat more.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="max-w-xl mx-auto mt-10">
      <CardContent>
        <h2 className="text-lg font-semibold mb-4">{current.text}</h2>
        {current.options ? (
          <div className="space-y-2">
            {current.options.map(option => (
              <Button key={option} onClick={() => handleAnswer(option)}>{option}</Button>
            ))}
          </div>
        ) : (
          <div>
            <input
              type="text"
              className="w-full p-2 border rounded mb-4"
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleAnswer(e.target.value);
              }}
              placeholder="Type your answer and hit Enter"
              autoFocus
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
}
